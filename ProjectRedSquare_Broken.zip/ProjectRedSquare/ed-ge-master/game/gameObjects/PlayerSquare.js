import  Components from "../../engine/Components.js"
import Base from "../../engine/Base.js"
import RectangleBehavior from "../behaviors/RectangleBehavior.js";


class PlayerSquare extends Base.GameObject {
  constructor(x, y) {
    super(x, y);
    let rectangleComponent = new Components.RectangleComponent(20, 20, "red", "blue");
    let rectangleBehavior = new RectangleBehavior();
    this.addComponent(rectangleComponent);
    this.addComponent(rectangleBehavior);
  }

}

export default PlayerSquare;