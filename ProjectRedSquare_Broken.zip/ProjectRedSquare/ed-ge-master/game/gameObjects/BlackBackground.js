import  Components from "../../engine/Components.js"
import Base from "../../engine/Base.js"

export default class BlackBackground extends Base.GameObject{
  constructor(x, y) {
    super(x, y)
    let backgroundComponent = new Components.BackgroundComponent(2000,2000);
    this.addComponent(backgroundComponent);
  }

}