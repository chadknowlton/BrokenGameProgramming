import  Components from "../../engine/Components.js"
import Base from "../../engine/Base.js"
import WeaponBehavior from "../behaviors/WeaponBehavior.js";


class PlayerWeapon extends Base.GameObject {
  constructor() {
    super();
    let weaponComponent = new Components.WeaponComponent();
    let weaponBehavior = new WeaponBehavior();
    this.addComponent(weaponBehavior);
    this.addComponent(weaponComponent);
  }

}

export default PlayerWeapon;