import RectangleBehavior from "./behaviors/RectangleBehavior.js";
import WeaponBehavior from "./behaviors/WeaponBehavior.js";

export default{
  RectangleBehavior,
  WeaponBehavior
}