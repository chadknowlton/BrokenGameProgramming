import Base from "../../engine/Base.js"
import PlayerSquare from '../gameObjects/PlayerSquare.js'
import BlackBackground from "../gameObjects/BlackBackground.js";
import PlayerWeapon from "../gameObjects/PlayerWeapon.js";


export default class SceneOne extends Base.Scene {
  constructor() {
    super();


    let blackBackground = new BlackBackground(0,0);
    this.gameObjects.push(blackBackground);

    let playerSquare = new PlayerSquare(400,400);
    this.gameObjects.push(playerSquare);

    let playerWeapon = new PlayerWeapon();
    this.gameObjects.push(playerWeapon);

  }
}