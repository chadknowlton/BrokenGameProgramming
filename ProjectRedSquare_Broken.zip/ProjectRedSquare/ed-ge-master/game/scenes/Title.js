import Base from "../../engine/Base.js"
import BlackBackground from "../gameObjects/BlackBackground.js";
import SceneManager from "../SceneManager.js";

export default class SceneOne extends Base.Scene {
  constructor() {
    super();


    let blackBackground = new BlackBackground(0,0);
    this.gameObjects.push(blackBackground);

    //TODO when enter is pressed, go to Scene 1
  }
}