import Base from "../../engine/Base.js"

export default class SceneTwo extends Base.Scene{
  constructor(){
    super();
    
  }
}