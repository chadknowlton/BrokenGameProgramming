import BlackBackground from "./gameObjects/BlackBackground.js"
import PlayerSquare from "./gameObjects/PlayerSquare.js"


export default {
  BlackBackground,
  PlayerSquare,
  PlayerWeapon
}