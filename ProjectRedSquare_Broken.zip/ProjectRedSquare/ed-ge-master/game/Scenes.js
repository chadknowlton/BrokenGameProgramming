import Title from "./scenes/Title.js"
import SceneOne from "./scenes/SceneOne.js"
import SceneTwo from "./scenes/SceneTwo.js"

export default{
  Title,
  SceneOne,
  SceneTwo,
}