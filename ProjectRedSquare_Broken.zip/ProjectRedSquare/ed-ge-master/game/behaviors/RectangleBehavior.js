import Base from "../../engine/Base.js"
import Components from "../../engine/Components.js"
import Input from "../../engine/base/Input.js";

class RectangleBehavior extends Base.Behavior{
    start(){
    }
    update(){
        if (Input.keys['ArrowUp']) {
            if (this.gameObject.getComponent(Components.RectangleComponent).y - 10 >= 0)
            {
                this.gameObject.getComponent(Components.RectangleComponent).y -= 10;
            }
        }
        if (Input.keys['ArrowDown']) {
            if (this.gameObject.getComponent(Components.RectangleComponent).y + 10 <= this.gameObject.getComponent(Components.BackgroundComponent).height)
            {
                this.gameObject.getComponent(Components.RectangleComponent).y += 10;
            }

        }
        if (Input.keys['ArrowLeft']) {
            if (this.gameObject.getComponent(Components.RectangleComponent).x - 10 >= 0)
            {
                this.gameObject.getComponent(Components.RectangleComponent).x -= 10;
            }

        }
        if (Input.keys['ArrowRight']) {
            if (this.gameObject.getComponent(Components.RectangleComponent).x + 10 <= this.gameObject.getComponent(Components.BackgroundComponent).width)
            {
                this.gameObject.getComponent(Components.RectangleComponent).x += 10;
            }

        }
    }
}

export default RectangleBehavior;