import Base from "../../engine/Base.js"
import Components from "../../engine/Components.js"
import Input from "../../engine/base/Input.js";

class WeaponBehavior extends Base.Behavior{
    start(){
    }
    update(){
        if (Input.keys['w']) {
            this.gameObject.getComponent(Components.WeaponComponent).y -= 10;
        }
        else if (Input.keys['s']) {
            this.gameObject.getComponent(Components.WeaponComponent).y += 10;

        }
        else if (Input.keys['a']) {
            this.gameObject.getComponent(Components.WeaponComponent).x -= 10;
        }
        else if (Input.keys['d']) {
            this.gameObject.getComponent(Components.WeaponComponent).x += 10;
        }
    } 
}

export default WeaponBehavior;