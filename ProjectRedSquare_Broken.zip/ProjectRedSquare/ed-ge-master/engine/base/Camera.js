import GameObject from "./GameObject.js"

class Camera extends GameObject{
    
    backgroundColor = "black";
    constructor(){

    }
}

export default Camera;