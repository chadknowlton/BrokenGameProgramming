import RectangleComponent from "./components/RectangleComponent.js"
import BackgroundComponent from "./components/BackgroundComponent.js"
import WeaponComponent from "./components/WeaponComponent.js"

export default {
  BackgroundComponent,
  RectangleComponent,
  WeaponComponent
}