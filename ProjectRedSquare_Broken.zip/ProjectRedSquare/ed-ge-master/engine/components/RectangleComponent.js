import Base from "../Base.js"

class RectangleComponent extends Base.Component{
    x;
    y;
    fill;
    stroke;
    constructor(x, y, fill, stroke){
        super();
        this.x = x;
        this.y = y;
        this.fill = fill;
        this.stroke = stroke;
    }
    draw(ctx){
        ctx.save();
        ctx.fillStyle = this.fill;
        ctx.strokeStyle = this.stroke;
        ctx.fillRect(this.x,this.y, 50,50);
        ctx.strokeRect(this.x,this.y, 50,50);
        ctx.restore();
    }
    update(){

    }
}

export default RectangleComponent;