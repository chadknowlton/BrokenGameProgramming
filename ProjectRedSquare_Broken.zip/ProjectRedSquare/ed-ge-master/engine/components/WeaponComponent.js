import Base from "../Base.js"

class WeaponComponent extends Base.Component{
    x;
    y;
    constructor(){
        super();
        this.x =  250;
        this.y =  250;
    }
    draw(ctx){
        ctx.save();
        ctx.fillStyle = "white";
        ctx.strokeStyle = "white";
        ctx.fillRect(this.x,this.y, 15,15);
        ctx.strokeRect(this.x,this.y, 15,15);
        ctx.restore();
    }
    update(){

    }
}

export default WeaponComponent;