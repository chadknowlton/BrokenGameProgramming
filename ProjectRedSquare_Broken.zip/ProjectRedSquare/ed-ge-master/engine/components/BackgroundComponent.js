import Base from "../Base.js"

class BackgroundComponent extends Base.Component{
    width;
    height;
    constructor(width, height){
        super();
        this.width = width;
        this.height = height;
        this.fill = "black";
        this.stroke = "black";
    }
    draw(ctx){
        ctx.save();
        ctx.translate(-this.width/2, -this.height/2);
        ctx.fillStyle = this.fill;
        ctx.strokeStyle = this.stroke;
        ctx.fillRect(0,0, this.width, this.height);
        ctx.strokeRect(0, 0, this.width, this.height);
        ctx.restore();
    }
    update(){

    }
}

export default BackgroundComponent;